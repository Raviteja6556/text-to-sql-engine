# GitHub Repository Settings
# Copy these into your repository's About section on GitHub

## Repository Description (max 350 chars):
Schema-aware Text-to-SQL engine — natural language to DuckDB SQL via RAG pipeline (ChromaDB + Sentence Transformers) + Gemini 2.5 Flash + FastAPI backend + Streamlit frontend. Handles LLM hallucination, markdown stripping, and custom JSON serialization.

## Topics (add these as repository tags):
text-to-sql
rag
langchain
gemini
chromadb
fastapi
duckdb
streamlit
sentence-transformers
nlp
generative-ai
llm
python
machine-learning
data-science

## Website:
(Add your deployed Streamlit URL here if available)
